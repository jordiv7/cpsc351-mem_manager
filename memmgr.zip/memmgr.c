//
//  memmgr.c
//  memmgr
//
//  Created by William McCarthy on 17/11/20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/mman.h>
#include <fcntl.h>

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256


//-------------------------------------------------------------------
unsigned getpage(unsigned x) { return (0xff00 & x) >> 8; }

unsigned getoffset(unsigned x) { return (0xff & x); }

void getpage_offset(unsigned x) {
  unsigned  page   = getpage(x);
  unsigned  offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}

/* void pageTableCheck(unsigned &frame, int pageTable[], unsigned page, int &pageFault, int &free_page, unsigned &physical_add, unsigned offset) {
    frame = pageTable[page];
        if (frame == -1)
        {
            pageFault++;
            frame = free_page;
            free_page++;

            pageTable[page] = frame;
        }
        physical_add = pageTable[page] * FRAME_SIZE + offset;
}
*/

int main(int argc, const char* argv[]) {
  FILE* fadd = fopen(argv[1], "r");    // open file addresses.txt  (contains the logical addresses)
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }

  FILE* fcorr = fopen("correct.txt", "r");     // contains the logical and physical address, and its value
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }

  int fBACK = open("BACKING_STORE.bin", O_RDONLY);     // open file BACKING_STORE.bin
  if (fBACK < 0) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n");  exit(FILE_ERROR);  }

  char buf[BUFLEN];
  unsigned   page, offset, physical_add, frame = 0;
  unsigned   logic_add;                  // read from file address.txt
  unsigned   virt_add, phys_add, value;  // read from file correct.txt

  int pageFault = 0;
  int TLB_hit = 0;
  int TLB_miss = 0;
  int pageTable[256];
  char mem[65536];
  int TLB[16][3];
  int total_add = 0;
  int frame_number;
  int free_page = 0;
  char *backing_ptr = mmap(0, 65536, PROT_READ, MAP_PRIVATE, fBACK, 0);

  int full = 0;

  //initialize all the page table entries to -1
  for (int i = 0; i < 256; i++) { pageTable[i] = -1; }

  //initialize all the TLB entries to -1
  for (int i = 0; i < 16; i++)  { for (int j = 0; j < 3; j++) { TLB[i][j] = -1; } }

  printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");

  // not quite correct -- should search page table before creating a new entry
      //   e.g., address # 25 from addresses.txt will fail the assertion
      // TODO:  add page table code
      // TODO:  add TLB code
  while (total_add < 1000) {

    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page   = getpage(  logic_add);
    offset = getoffset(logic_add);

    total_add++;
    int hit = 0;                           // Will act as bool
    int miss = 0;                          // Will act as bool
    int complete = 0;                      // Will act as bool
    //Getting from the TLB
    for (int i = 0; i < 16; i++)
    {
        if (page == TLB[i][0])
        {
            hit = 1;
            miss = 0;
            TLB_hit++;
            frame = TLB[i][1];
        }    
        else
            miss = 1;
            hit = 0;
    }
    //hit = 0;
    //miss = 1;
    
    if (miss)
    {
        TLB_miss++;
        /* if (TLB_miss > 16)
        {
            frame = pageTable[page];
            if (frame == -1)
            {
                pageFault++;
                frame = free_page;
                free_page++;

                pageTable[page] = frame;
            }
            physical_add = pageTable[page] * FRAME_SIZE + offset;
            for (int i = 0; i < 16; i++) {
                if (TLB[i][2] == (TLB_miss - 1)%16) {
                    TLB[i][0] = page;
                    TLB[i][1] = frame;
                    complete = 1;
                    break;
                }
            }
        } */

        for (int i = 0; i < 16; i++)
        {
            if (complete == 1) break;
            if (full == 1) break;
            if (TLB[i][2] == -1)
            {
                TLB[i][0] = page;
                //Getting from the page table
                frame = pageTable[page];
                if (frame == -1)
                {
                    pageFault++;
                    frame = free_page;
                    free_page++;

                    memcpy(mem + frame * FRAME_SIZE, backing_ptr + page * FRAME_SIZE, FRAME_SIZE);

                    pageTable[page] = frame;
                }
                physical_add = pageTable[page] * FRAME_SIZE + offset;
                
                TLB[i][1] = frame;
                TLB[i][2] = (TLB_miss - 1)%16;
                complete = 1;
                if (i == 15)
                    full = 1;
                break;
            }         
        }
    }

    //Getting from the page table
    if (!hit && !complete) {
        frame = pageTable[page];
        if (frame == -1)
        {
            pageFault++;
            frame = free_page;
            free_page++;

            memcpy(mem + frame * FRAME_SIZE, backing_ptr + page * FRAME_SIZE, FRAME_SIZE);

            pageTable[page] = frame;
        }
        physical_add = pageTable[page] * FRAME_SIZE + offset;
    }
    //frame++;
    
    //physical_add = frame++ * FRAME_SIZE + offset;
    
    assert(physical_add == phys_add);
    
    // todo: read BINARY_STORE and confirm value matches read value from correct.txt
    
    printf("logical: %5u (page: %3u, offset: %3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
    if (frame % 5 == 0) { printf("\n"); }
  }
  fclose(fcorr);
  fclose(fadd);
  
  printf("Read %d entries\n", total_add);
  printf("Page Faults: %d\n", pageFault);
  printf("Page Fault Rate = %.1f %\n", (pageFault / (total_add*1.))*100);
  printf("TLB hits: %d\n", TLB_hit);
  printf("TLB hit Rate = %.1f %\n", (TLB_hit / (total_add*1.))*100);

  printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");
  
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("!!! This doesn't work passed entry 24 in correct.txt, because of a duplicate page table entry\n");
  printf("--- you have to implement the PTE and TLB part of this code\n");

//  printf("NOT CORRECT -- ONLY READ FIRST 20 ENTRIES... TODO: MAKE IT READ ALL ENTRIES\n");

  printf("\n\t\t...done.\n");
  return 0;
}
